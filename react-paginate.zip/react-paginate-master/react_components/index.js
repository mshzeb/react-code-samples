import PaginationBoxView from './PaginationBoxView';

module.exports = PaginationBoxView;
